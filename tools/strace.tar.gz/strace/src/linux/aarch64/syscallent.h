/*
 * Copyright (c) 2012-2021 The strace developers.
 * All rights reserved.
 *
 * SPDX-License-Identifier: LGPL-2.1-or-later
 */

#include "../64/syscallent.h"

/*
 * Arch-specific block, not used on AArch64.
 * [244 ... 259] = { },
 */
