#include "syscallent-compat.h"
#include "syscallent-o32.h"
#include "syscallent-n64.h"
#include "syscallent-n32.h"
