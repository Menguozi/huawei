/*
 * Copyright (c) 1999-2021 The strace developers.
 * All rights reserved.
 *
 * SPDX-License-Identifier: LGPL-2.1-or-later
 */

	"0",		/* 0 */
	"SIGHUP",	/* 1 */
	"SIGINT",	/* 2 */
	"SIGQUIT",	/* 3 */
	"SIGILL",	/* 4 */
	"SIGTRAP",	/* 5 */
	"SIGIOT",	/* 6 */
	"SIGEMT",	/* 7 */
	"SIGFPE",	/* 8 */
	"SIGKILL",	/* 9 */
	"SIGBUS",	/* 10 */
	"SIGSEGV",	/* 11 */
	"SIGSYS",	/* 12 */
	"SIGPIPE",	/* 13 */
	"SIGALRM",	/* 14 */
	"SIGTERM",	/* 15 */
	"SIGUSR1",	/* 16 */
	"SIGUSR2",	/* 17 */
	"SIGCHLD",	/* 18 */
	"SIGPWR",	/* 19 */
	"SIGWINCH",	/* 20 */
	"SIGURG",	/* 21 */
	"SIGIO",	/* 22 */
	"SIGSTOP",	/* 23 */
	"SIGTSTP",	/* 24 */
	"SIGCONT",	/* 25 */
	"SIGTTIN",	/* 26 */
	"SIGTTOU",	/* 27 */
	"SIGVTALRM",	/* 28 */
	"SIGPROF",	/* 29 */
	"SIGXCPU",	/* 30 */
	"SIGXFSZ",	/* 31 */
	"SIGRTMIN",	/* 32 */
