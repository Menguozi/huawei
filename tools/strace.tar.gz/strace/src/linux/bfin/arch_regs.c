/*
 * Copyright (c) 2015-2021 The strace developers.
 * All rights reserved.
 *
 * SPDX-License-Identifier: LGPL-2.1-or-later
 */

static unsigned long bfin_r0;
#define ARCH_PC_PEEK_ADDR PT_PC
#define ARCH_SP_PEEK_ADDR PT_USP
