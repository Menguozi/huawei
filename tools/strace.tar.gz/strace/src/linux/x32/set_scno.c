#include "../x86_64/set_scno.c"
