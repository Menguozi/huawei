#include "../powerpc/syscallent.h"
