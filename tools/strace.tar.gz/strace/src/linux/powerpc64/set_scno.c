#include "../powerpc/set_scno.c"
