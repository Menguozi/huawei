#include "../powerpc/get_syscall_args.c"
