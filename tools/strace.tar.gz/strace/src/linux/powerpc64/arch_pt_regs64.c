/*
 * Copyright (c) 2021 The strace developers.
 * All rights reserved.
 *
 * SPDX-License-Identifier: LGPL-2.1-or-later
 */

#include "arch_pt_regs64.h"

#include "../powerpc/arch_pt_regs64.c"
