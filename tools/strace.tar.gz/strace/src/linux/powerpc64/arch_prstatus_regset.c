#include "../powerpc/arch_prstatus_regset.c"
