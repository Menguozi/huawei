#include "../sparc/set_scno.c"
