#include "../sparc/ioctls_arch0.h"
