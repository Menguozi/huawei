#include "../sparc/arch_getrval2.c"
